import { Platform } from 'react-native';

if (Platform.OS === 'web' && typeof document !== 'undefined') {
  const manifestLink = document.createElement('link');
  manifestLink.rel = 'manifest';
  manifestLink.href = '/manifest.json';
  document.head.appendChild(manifestLink);

  const theme = document.createElement('meta');
  theme.name = 'theme-color';
  theme.content = '#0b0618';
  document.head.appendChild(theme);

  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js').catch((error) => {
        console.warn('LineGuard offline support could not be enabled:', error);
      });
    });
  }
}
