export const C = {
  purple: '#9b5cff', purple2: '#a56bff', pink: '#ec4899', orange: '#ff6b1a',
  white: '#ffffff', off: '#0b0618', card: '#1b0d31', card2: '#24103d',
  border: '#351653', text: '#f8f2ff', muted: '#c1addb', light: '#a58bc4', xlight: '#9475b8',
  green: '#21c58b', greenBg: '#10352f', red: '#f05b70', redBg: '#3a1728',
  amber: '#f59e0b', amberBg: '#3b2813',
};
export const G = {
  main: ['#4b1688', '#95136f', '#bd3d12'],
  purplePink: ['#6d20b7', '#a41478', '#c63d14'],
  deep: ['#35105f', '#7c1b8e'],
  green: ['#10b981', '#06b6d4'],
  dark: ['#6d20b7', '#c02675'],
};
export const MIN_REP = 50;
export const START_REP = 100;
export function repLevel(rep) {
  if (rep >= 150) return { label: 'Guardian', color: '#a56bff' };
  if (rep >= 100) return { label: 'Trusted', color: '#21c58b' };
  if (rep >= 75) return { label: 'Active', color: '#38a3ff' };
  if (rep >= MIN_REP) return { label: 'Caution', color: '#f59e0b' };
  return { label: 'Suspended', color: '#f05b70' };
}
