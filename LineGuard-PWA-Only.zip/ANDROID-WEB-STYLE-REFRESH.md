# LineGuard Android visual refresh

This update restyles the Expo Android app toward the dark LineGuard web look shown in the supplied screenshots:
- deep near-black purple page background
- dark violet cards and borders
- purple-to-magenta-to-orange brand gradients
- light text and lavender secondary text
- dark bottom navigation with purple active state
- existing screens, navigation, and feature logic retained

The uploaded project ZIP did not include the standalone `lineguard-web.html` source referenced by the README. This is therefore a screenshot-guided visual match, not a pixel-perfect port of the website source. The web HTML/CSS would be needed for exact spacing, typography, and every interaction state.

No APK was built or device-tested here. Upload this project to GitHub and run the Android APK workflow to produce a test build.
