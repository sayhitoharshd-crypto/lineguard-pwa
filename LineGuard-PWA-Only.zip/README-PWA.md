# LineGuard PWA

This is the web/PWA version of LineGuard. It is intended to run in a browser and be installable from Chrome on Android. It does not create an APK.

## Build the website

Use Node.js 20 or newer:

```bash
npm install
npx expo export --platform web
```

The static website is generated in the `dist/` folder. Deploy the contents of `dist/` to a static HTTPS host (for example, Netlify, Vercel, or Firebase Hosting).

For local web development:

```bash
npm install
npx expo start --web
```

## Install on Android

After the website is deployed over HTTPS:
1. Open its URL in Chrome on Android.
2. Open Chrome's three-dot menu.
3. Tap **Install app** or **Add to Home screen**.

## Firebase setup still required

The web client uses the Firebase project already configured in `SRC/firebase/config.web.js`. In Firebase Console, add the deployed website domain to Authentication > Settings > Authorized domains. Enable the sign-in providers you intend to use. Google sign-in uses the configured Web OAuth client ID; make sure its authorized JavaScript origins include your deployed HTTPS domain.

Cloud Functions, Firestore rules, indexes, and Storage rules still need to be deployed to Firebase before protected app actions will work. This archive has not been deployed or tested against the live Firebase project. The service worker caches the app shell and static assets; Firebase/API requests are deliberately not cached.

## Important

This is a PWA source project, not a live hosted website. A public HTTPS URL is created only after deploying the generated `dist/` folder to a hosting provider.
