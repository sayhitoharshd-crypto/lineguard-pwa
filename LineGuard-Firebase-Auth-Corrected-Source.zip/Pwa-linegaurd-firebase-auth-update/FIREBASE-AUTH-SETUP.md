# LineGuard Firebase Android authentication update

This source keeps the original LineGuard Expo app and adds native Firebase Authentication.

## Included
- Firebase Email/Password sign-up and sign-in.
- Firebase password reset email.
- Firebase Phone OTP sign-in using the native Firebase Android SDK.
- Firebase auth-state listener; no locally stored plaintext passwords.
- No Google Sign-In.
- Android package remains `com.lineguard.app`.
- GitHub Actions builds on `main` and `firebase-auth-update` pushes and copies `google-services.json` before Expo prebuild.

## Required Firebase Console setup before testing
1. In Firebase Authentication, enable Email/Password and Phone providers.
2. Add the SHA-1 and SHA-256 fingerprints of the Android signing certificate used by the build to the Firebase Android app (`com.lineguard.app`). Download a fresh `google-services.json` after updating the app settings if Firebase asks for it.
3. For production phone authentication, configure SMS region policy and test with a real device/number or Firebase test numbers.

Phone OTP is real Firebase phone auth, not a mock. It will fail until Firebase provider settings and signing fingerprints are correct. The workflow build still needs to be run in GitHub Actions to confirm dependency resolution and produce the APK.
